package ingredients;

public class IngredientFactory {
	public Ingredient createIngredient(String name, double priceperquantity) {
		return new Ingredient(name, priceperquantity);
	}
	
	public Ingredient createIngredient(String name, double quantity, double priceperquantity){
		return new Ingredient(name, quantity, priceperquantity);
	}
	
}
